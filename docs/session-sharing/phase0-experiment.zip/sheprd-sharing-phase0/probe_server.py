"""Loopback-only phase-0 transport fixture. Not the production relay."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import base64,hashlib,json,struct,subprocess
ROOT=Path(__file__).parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT/'web'),**kw)
 def log_message(self,*args):pass
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0'))
  if self.path!='/result' or n>16384 or self.headers.get('Origin')!=f'http://{self.headers.get("Host")}':
   self.send_error(403);return
  report=json.loads(self.rfile.read(n));(ROOT/'result.json').write_text(json.dumps(report,indent=2));self.send_response(204);self.end_headers()
 def do_GET(self):
  if self.path!='/ws':return super().do_GET()
  if self.headers.get('Origin')!=f'http://{self.headers.get("Host")}':self.send_error(403);return
  key=self.headers.get('Sec-WebSocket-Key','')
  if self.headers.get('Upgrade','').lower()!='websocket' or len(key)>128:self.send_error(400);return
  self.send_response(101);self.send_header('Upgrade','websocket');self.send_header('Connection','Upgrade');self.send_header('Sec-WebSocket-Accept',base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode());self.end_headers()
  self.connection.settimeout(10)
  process=subprocess.Popen([str(ROOT/'target/debug/host')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   identity=process.stdout.readline(8192).strip();self.send_frame(identity,1)
   for _ in range(12):
    payload=self.read_frame()
    if payload is None:break
    process.stdin.write(payload.hex().encode()+b'\n');process.stdin.flush()
    response=process.stdout.readline(131072).strip()
    if not response:break
    self.send_frame(bytes.fromhex(response.decode()),2)
  except (OSError,ValueError,EOFError):pass
  finally:
   process.terminate();process.communicate(timeout=3);self.close_connection=True
 def send_frame(self,payload,op):
  n=len(payload);self.wfile.write(bytes([128|op,n]) if n<126 else bytes([128|op,126])+struct.pack('!H',n));self.wfile.write(payload);self.wfile.flush()
 def exact(self,n):
  b=self.rfile.read(n)
  if len(b)!=n:raise EOFError()
  return b
 def read_frame(self):
  a,b=self.exact(2)
  if a&15==8:return None
  if a!=130 or not b&128:raise ValueError('Only final masked binary frames')
  n=b&127
  if n==126:n=struct.unpack('!H',self.exact(2))[0]
  if n==127 or n>65535:raise ValueError('Oversize')
  mask=self.exact(4);data=self.exact(n)
  return bytes(x^mask[i%4] for i,x in enumerate(data))
if __name__=='__main__':
 server=ThreadingHTTPServer(('127.0.0.1',8927),Handler)
 print('http://127.0.0.1:8927',flush=True);server.serve_forever()
