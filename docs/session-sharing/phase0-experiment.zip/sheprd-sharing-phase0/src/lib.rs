#![cfg(target_arch = "wasm32")]
use sheprd_tunnel::{Identity, Initiator, Keys, Transport, record::Opened};
use std::time::Duration;
use wasm_bindgen::prelude::*;

fn error(e: impl std::fmt::Display) -> JsValue {
    JsValue::from_str(&e.to_string())
}
#[wasm_bindgen]
pub struct Guest {
    pending: Option<Initiator>,
    transport: Option<Transport>,
    first: Vec<u8>,
}
#[wasm_bindgen]
impl Guest {
    #[wasm_bindgen(constructor)]
    pub fn new(identity: &[u8], route: &[u8]) -> Result<Guest, JsValue> {
        let route: [u8; 32] = route.try_into().map_err(error)?;
        let remote = Identity::from_bytes(identity).map_err(error)?;
        let keys = Keys::generate().map_err(error)?;
        let (pending, first) = Initiator::session(&keys, &remote, &route).map_err(error)?;
        Ok(Self {
            pending: Some(pending),
            transport: None,
            first,
        })
    }
    pub fn first(&self) -> Vec<u8> {
        self.first.clone()
    }
    pub fn finish(&mut self, answer: &[u8]) -> Result<(), JsValue> {
        let pending = self
            .pending
            .take()
            .ok_or_else(|| error("No pending handshake"))?;
        self.transport = Some(pending.finish(answer).map_err(error)?.0);
        Ok(())
    }
    pub fn seal(&mut self, data: &[u8], elapsed_ms: u32) -> Result<Vec<u8>, JsValue> {
        self.transport
            .as_mut()
            .ok_or_else(|| error("No transport"))?
            .seal(data, Duration::from_millis(u64::from(elapsed_ms)))
            .map_err(error)
    }
    pub fn open(&mut self, data: &[u8]) -> Result<Vec<u8>, JsValue> {
        match self
            .transport
            .as_mut()
            .ok_or_else(|| error("No transport"))?
            .open(data)
            .map_err(error)?
        {
            Opened::Data(data) => Ok(data),
            Opened::Closed => Err(error("Closed")),
        }
    }
}
