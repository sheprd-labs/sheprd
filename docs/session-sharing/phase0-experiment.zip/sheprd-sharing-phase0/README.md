# Shared-session Phase 0 experiment

Source: Sheprd commit 4ab49ed3ee744dc48bae6a18a565d220c4526b48.
This is an isolated experiment, NOT production code or a deployable server.
No real session data, credentials, or fleet enrollment is used.

The tunnel/ directory is a disposable copy of sheprd-tunnel. Only record timing
was changed (Instant -> elapsed Duration), and Snow's std feature was disabled.
The original copied tests still describe the original clock API; they are not
part of this probe. The executable probe is web/index.html with seven cases.
The native endpoint is src/bin/host.rs. The browser wrapper is src/lib.rs.
The loopback WebSocket fixture is probe_server.py. It is NOT sheprd-relay and
accepts synthetic guests without authentication. Never deploy it or bind it to
a public interface. The wrapper uses fresh random keys, not fixed test secrets.

Requirements: Rust 1.99.0, wasm32-unknown-unknown target, Python 3.14 (stdlib only),
and official wasm-bindgen CLI 0.2.128. Production workspace dependencies were
not changed. The experiment reused pinned dependencies from its Cargo.lock.

From the extracted directory:

    cargo build --locked --bin host
    cargo build --locked --target wasm32-unknown-unknown --lib
    wasm-bindgen target/wasm32-unknown-unknown/debug/sharing_phase0.wasm --target web --out-dir web/pkg
    python3 probe_server.py

Then open http://127.0.0.1:8927/ in a browser. Read result.json after it finishes.
Stop the fixture with Ctrl-C. The browser uses loopback HTTP/WS, not production
TLS. Debug build performance is not a release performance measurement.

Checks run on the wrapper:

    cargo fmt
    cargo clippy --locked --offline --lib --bin host -- -D warnings
    cargo clippy --locked --offline --target wasm32-unknown-unknown --lib -- -D warnings

The archive excludes build products, native binaries, and downloaded tools.
The production relay origin/revocation suites were run separately in the repo;
see session-sharing-phase0.md and session-sharing-phase0-evidence.json.
